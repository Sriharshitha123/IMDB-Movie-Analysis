# IMDb-Webscrapping-with-EDA

## Use case domain understanding​

Movie analysis based on the features with IMDb data as a source

## Objective of the Project​

To analyze the data based on their features and make possible conclusions of the movies liked by the audience.
